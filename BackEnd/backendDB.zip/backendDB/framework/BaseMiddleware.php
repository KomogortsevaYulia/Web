<?php

class BaseMiddleware {
    public function apply(BaseController $controller, array $context) {
        
    }
}